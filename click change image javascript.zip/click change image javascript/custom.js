let parentImage = document.getElementById("first_image");

function myImageFun_1() {
    parentImage.src = "images/2.jpg";
}

function myImageFun_2() {
    parentImage.src = "images/3.jpg";
}

function myImageFun_3() {
    parentImage.src = "images/4.jpg";
}

function myImageFun_4() {
    parentImage.src = "images/5.jpg";
}
